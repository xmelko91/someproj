from main_window import *

if __name__ == '__main__':

    app = QApplication(sys.argv)
    ex = enterWindow()

    sys.exit(app.exec_())
